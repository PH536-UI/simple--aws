def lambda_handler(event, context):
    nome = event.get('nome', 'Phcavalheiro76') if isinstance(event, dict) else 'Phcavalheiro76'
    return {
        'statusCode': 200,
        'body': f'Olá {nome} - Floci 135 serviços - fake lambda OK'
    }
